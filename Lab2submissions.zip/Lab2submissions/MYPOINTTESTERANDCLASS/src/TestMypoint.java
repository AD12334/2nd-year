public class TestMypoint {
    public static void main(String[] args){
        MyPoint mypoint1 = new MyPoint(2,2);
        MyPoint mypoint2 = new MyPoint(3,3);
        System.out.println("X value = " + mypoint1.getX());
        System.out.println("Y value = " + mypoint1.getY());
        System.out.println("X value for point 2 = " + mypoint2.getX());
        System.out.println("Y value for point 2 = " + mypoint2.getY());
        System.out.println("The distance between the two points is " + mypoint1.distance(mypoint2));
        System.out.println("The distance between the point " + "(" + mypoint1.getX() +"," + mypoint1.getY() + ")" + " and the point (4,5) is " +  mypoint1.distance(mypoint2,4,5));
    }
}
