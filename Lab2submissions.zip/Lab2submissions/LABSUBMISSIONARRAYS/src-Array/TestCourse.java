public class TestCourse {
    public static void main(String[] args){
        // Create new course instance
        Course course = new Course("AIML");

        //Add three students
        course.addStudent("John");
        course.addStudent("Tim");
        course.addStudent("Chris");

        System.out.println("Students before removal: ");
        course.displayStudents();

        //Remove student
        course.dropStudent("Tim");

        System.out.println("Students after removing Tim: ");
        course.displayStudents();
    }
}
