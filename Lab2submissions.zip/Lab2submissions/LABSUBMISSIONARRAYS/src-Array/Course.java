import java.util.Arrays;
//This implementation of the java course was done by my lab partner Euan Jennings id: 23371404
public class Course {
    private String courseName;
    private String[] students = new String[4];
    private int numberOfStudents;

    /**
     * Constructor to initialize Course
     *
     * @param courseName The name of the course
     */
    public Course(String courseName) {

        this.courseName = courseName;//Set the coursename
    }

    /**
     * Adds a student to an array of students
     * If array is full will double the size to accommodate more students
     *
     * @param student The name of the student to be added
     */
    public void addStudent(String student) {
        if(numberOfStudents == students.length){ //if the number of students in the array is equal to the length of the array then the array must be full
            String[] newList = new String[students.length * 2];//Make a new array double the size of the previous array
            System.arraycopy(students, 0, newList, 0, students.length);//Copy in the old array values
            students = newList;//replace the old array with the new array
        }
        students[numberOfStudents] = student; // add the student to the new array at the required index
        numberOfStudents++;//Increase the number of students by one
    }

    public void dropStudent(String remove) {
        int index = numberOfStudents;//Initializing an index to iterate through the array
        for (int i=0; i < students.length; i++){
            if (remove.equals(students[i])){//if the name of the student we wish to remove matches the student name at the position in the index
                index = i;//Resizing the array
                numberOfStudents --;//Decrementing the number of students by one
            }
        }

        String[] updatedList =new String[students.length];//Updating the new array
        System.arraycopy(students, 0, updatedList, 0, index);//Copying the left side of the removed student into the new array
        System.arraycopy(students, index + 1, updatedList, index, students.length - index - 1 );//Copying the right side of the removed student into the new array
        students = updatedList;// Replacing the old array with the new array
    }

    public void removeAllStudents(){
        Arrays.fill(students, null);//Removing all students from the array
        numberOfStudents = 0;
        System.out.println("All students have been removed.");
    }

    public String[] getStudents() {
        String[] studentsCopy = new String[students.length];//Implementing encapsulation by altering our code so that we do not return a reference to a mutable data field object
        System.arraycopy(students, 0, studentsCopy, 0, students.length);
        return studentsCopy;
    }

    public int getNumberOfStudents() {
        return numberOfStudents;
    }

    public String getCourseName() {
        return courseName;
    }

    public void displayStudents() {
        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println(students[i]);//Printing out the finished array
        }
    }
}