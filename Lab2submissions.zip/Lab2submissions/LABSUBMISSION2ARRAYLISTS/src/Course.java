import java.util.ArrayList;

//This is the lab submission for Adam Downes student id:23358173
public class Course {
    private String courseName;
    private int numberOfStudents;
    ArrayList<String> studentsList = new ArrayList<String>();//creating the arrayList


    public Course(String courseName) {

        this.courseName = courseName;
    }

    /**
     *
     *  name to be added, increases the number of students by one
     */
    public void addStudent(String student) {
        studentsList.add(student);//Adding the student to the arraylist
        numberOfStudents++;
    }

    /**
     *
     * returns a reference to the array of students
     */
    public String[] getStudents() {

        return studentsList.toArray(new String[studentsList.size()]);
        //returning a new studentslist object to achieve encapsulation
        //Any edits made to this new array won't effect the internal array
    }

    /**
     *
     *  returns the number of students as an int
     */
    public int getNumberOfStudents() {

        return numberOfStudents;
    }

    /**
     *
     *   returns the course name
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     *
     * drops a student from the array and reduces the number of students in the array by one
     */
    public void dropStudent(String student) {
        studentsList.remove(student);//Removing the student from the arrayList
        numberOfStudents--;
    }

    /**
     *  Removes all students from the arraylist
     */
    public void removeAllStudents() {
        studentsList.clear();//Clearing the arrayList
        numberOfStudents = 0;
    }

    /**
     * Prints the name of all the students in the array
     */
    public void printStudents() {
        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println(studentsList.get(i));

        }
    }

}
