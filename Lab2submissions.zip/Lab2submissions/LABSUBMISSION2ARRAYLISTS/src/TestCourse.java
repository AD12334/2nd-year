public class TestCourse{
    public static void main(String[] args){
        Course course = new Course("AI");
        course.addStudent("Adam");
        course.addStudent("Bob");
        course.addStudent("Dan");

        course.printStudents();
        course.dropStudent("Bob");
        System.out.println("Students after removing Bob:");
        course.printStudents();







    }
}
