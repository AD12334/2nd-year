import java.util.Scanner;
public class Excercise1_Q9{
  public static void displayLargestNumber(double num1,double num2,double num3){
            System.out.println("The largest number is " + Math.max(Math.max(num1,num2),num3));
        }
}

