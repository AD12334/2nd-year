import java.util.Scanner;
public class Excercise1_Q6{
   public static void Q6(){
    Scanner myObj = new Scanner(System.in);
    System.out.println("Enter year");
    int year = myObj.nextInt();
    System.out.println("Enter month 1 - 12");
    int m = myObj.nextInt();
    System.out.println("Enter day of the month");
    int q = myObj.nextInt();
    //January and Febuary are counted as month 13 and 14 of the previous year
    String[] months = new String[13];
    months[1] = "January";
    months[2] = "Febuary";
    months[3] = "March";
    months[4] = "April";
    months[5] = "May";
    months[6] = "June";
    months[7] = "July";
    months[8] = "August";
    months[9] = "September";
    months[10] = " October";
    months[11] = "November";
    months[12] = "December";
    if (m == 1 || m == 2 ){
        m += 12;
        year --;
    }
    int k = year%100;
    int j = year/100;
    int h = (int)(q + ((26*(m+1))/10 ) + k + (k/4) + (j/4) + (5*j));
    h = h%7;
    
    String[] day = new String[8];
    day[0] = "Saturday";
    day[1] = "Sunday";
    day[2] = "Monday";
    day[3] = "Tuesday";
    day[4] = "Wednesday";
    day[5] = "Thursday";
    day[6] = "Friday";
    System.out.println("The day of the week is " + day[h]);
    
}
}

