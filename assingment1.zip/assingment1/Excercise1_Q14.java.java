import java.util.Scanner;
public class Excercise1_Q14{
    public static void main(String[] args){
        //------- 
        //|X|O|X|
        //-------
        //|X|O|X|
        //-------
        //|X|O|X|
        //-------
        
        
        
        char[][] board = new char[7][7];
        board[0][0] ='-';
        board[0][1]='-';
        board[0][2] ='-';
        board[0][3] ='-';
        board[0][4] ='-';
        board[0][5] ='-';
        board[0][6] ='-';
        board[1][0]='|';
        board[1][2] ='|';
        board[1][4]='|';
        board[1][6] ='|';
         board[2][0] ='-';
        board[2][1]='-';
        board[2][2] ='-';
        board[2][3] ='-';
        board[2][4] ='-';
        board[2][5] ='-';
        board[2][6] ='-';
        board[3][0]='|';
        board[3][2] ='|';
        board[3][4]='|';
        board[3][6] ='|';
        board[4][0] ='-';
        board[4][1]='-';
        board[4][2] ='-';
        board[4][3] ='-';
        board[4][4] ='-';
        board[4][5] ='-';
        board[4][6] ='-';
        board[5][0]='|';
        board[5][2] ='|';
        board[5][4]='|';
        board[5][6] ='|';
        board[6][0] ='-';
        board[6][1]='-';
        board[6][2] ='-';
        board[6][3] ='-';
        board[6][4] ='-';
        board[6][5] ='-';
        board[6][6] ='-';
         int user=1;
        int win=0;
        int placed=0;
        for (int i =0;win<1 ; i++){
            Scanner myObj = new Scanner(System.in);
    System.out.println("Enter row co-ordinate (0,1,2) for player " + user + ":");//COLLECTING USER INPUTS
    int row1 = myObj.nextInt();
    System.out.println("Enter column co-ordinate (0,1,2) for player " + user + ":");
    int column1 =myObj.nextInt();
    if(placed>8){
        System.out.println("Draw");//IF 8 COUNTERS ARE PLACED WITHOUT A WIN THEN ITS A DRAW
    }
    if (user == 1){
       if (row1 == 0){
            row1 = 1;
        }else if (row1 ==1){
            row1 =3;
        }else if (row1== 2){
            row1 =5;
        }
        if (column1 == 0){
            column1 = 1;
        }else if (column1 ==1){
            column1 =3;
        }else if (column1== 2){
            column1 =5;
        }
        if(row1 != 1 && row1 != 3 && row1 != 5 ||column1 != 1 && column1 != 3 && column1 != 5||board[row1][column1]=='O'||board[row1][column1] =='X'){
        System.out.println("Invalid input turn forfeited ");
        user =2;
    }
     else{
        board[row1][column1] = 'X';
        placed++;
        user=2;
    }
        if (
    // Horizontal wins
    (board[1][1] == 'X' && board[1][3] == 'X' && board[1][5] == 'X') ||
    (board[3][1] == 'X' && board[3][3] == 'X' && board[3][5] == 'X') ||
    (board[5][1] == 'X' && board[5][3] == 'X' && board[5][5] == 'X') ||

    // Vertical wins
    (board[1][1] == 'X' && board[3][5] == 'X' && board[5][1] == 'X') ||
    (board[1][3] == 'X' && board[3][3] == 'X' && board[5][3] == 'X') ||
    (board[0][2] == 'X' && board[1][2] == 'X' && board[2][2] == 'X') ||

    // Diagonal wins
    (board[1][1] == 'X' && board[3][3] == 'X' && board[5][5] == 'X') ||
    (board[1][5] == 'X' && board[3][3] == 'X' && board[5][1] == 'X')) {
 System.out.println("Player 1 wins");
 win++;
}
for (int w = 0; w < board.length; w++) {
    for (int j = 0; j < board[w].length; j++) {
        System.out.print(board[w][j] + " ");

  
}
System.out.println();
}

}

 else{
      if (row1 == 0){
            row1 = 1;
        }else if (row1 ==1){
            row1 =3;
        }else if (row1== 2){
            row1 =5;
        }
        if (column1 == 0){
            column1 = 1;
        }else if (column1 ==1){
            column1 =3;
        }else if (column1== 2){
            column1 =5;
        }
    if(row1 != 1 && row1 != 3 && row1 != 5 ||column1 != 1 && column1 != 3 && column1 != 5||board[row1][column1]=='O'||board[row1][column1] =='X'){
        System.out.println("Invalid input turn forfeited ");
        user=1;
    }
   else{
        board[row1][column1] = 'O';
        placed++;
        user=1;
    }
         if (
    // Horizontal wins
    (board[1][1] == 'O' && board[1][3] == 'O' && board[1][5] == 'O') ||
    (board[3][1] == 'O' && board[3][3] == 'O' && board[3][5] == 'O') ||
    (board[5][1] == 'O' && board[5][3] == 'O' && board[5][5] == 'O') ||

    // Vertical wins
    (board[1][1] == 'O' && board[3][1] == 'O' && board[5][1] == 'O') ||
    (board[1][3] == 'O' && board[3][3] == 'O' && board[5][3] == 'O') ||
    (board[1][5] == 'O' && board[3][5] == 'O' && board[5][5] == 'O') ||

    // Diagonal wins
    (board[1][1] == 'O' && board[3][3] == 'O' && board[5][5] == 'O') ||
    (board[1][5] == 'O' && board[3][3] == 'O' && board[5][1] == 'O')) {
 System.out.println("Player 2 wins");
 win++;
}
for (int w = 0; w < board.length; w++) {
    for (int j = 0; j < board[w].length; j++) {
        System.out.print(board[w][j] + " ");

  
}
System.out.println();
}
}
}
}
}

