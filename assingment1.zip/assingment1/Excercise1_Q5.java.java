import java.util.Scanner;
public class Excercise1_Q5{
    public static void Q7(){
    int rng = ((int)(Math.random()*3));
    Scanner myObj = new Scanner(System.in);
    System.out.println("Input a number ");
    int userinput = myObj.nextInt();
    String[] options = new String[3];
    options[0] = "Scissors";
    options[1] = "rock";
    options[2] = "paper";
   
    //rock = 1
    //scisors = 0
    //paper = 2
    if (userinput > 2 || userinput < 0){
        System.out.println("Error number must be between 0 and 3");
    }else if (userinput == rng ){
         System.out.print("Computer picked " + options[rng]);
    System.out.println(".You picked " + options[userinput]);
    System.out.println("Draw");
    }
    else if ((userinput == 0 && rng == 1 )||(userinput==1 && rng == 2) || (userinput == 2 && rng ==0)){
         System.out.print("Computer picked " + options[rng]);
    System.out.println(".You picked " + options[userinput]);
        System.out.println(options[rng] + " beats " + options[userinput] + " you lose :( ");
    } else{
         System.out.print("Computer picked " + options[rng]);
    System.out.println(".You picked " + options[userinput]);
        System.out.println(options[userinput] +" beats " + options[rng] + " you win :) ");
    }
}
}

