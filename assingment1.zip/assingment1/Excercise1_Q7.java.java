import java.util.Scanner;
public class Excercise1_Q7{
   public static void Q7(){
    Scanner myObj = new Scanner(System.in);
    System.out.println("Input your number");
    int input =myObj.nextInt();
    int[] list= new int[input];
 int[] lists= new int[input];
    //a prime number can only be divided by one and itself.
    //make an array the size of the number/2
    //write a loop that checks through each number up 
    //to half the input and divides into the input 
    //if the type of the
    //number of divisors 
    System.out.print("Factors of " + input + " are: ");
    int count =0;
    for (int i =1;i <input; i++){
         
        if (input%i == 0){
            //System.out.print(i + " ");
            list[count] = i;
           
            System.out.print(list[count] + " ");
             count++;
        }
        
        
    }
    System.out.println();
    System.out.print("Prime Factors of " + input + " are: ");
    int counter = 0;
  for (int i =0;i <list.length; i++){//iterates through the list 
         for (int q = 1;q <list.length;q++){//Checks the number of factors for each factor
             if (list[i]%q == 0){//if a factor has more than two factors then it is not a prime number
                 counter ++;
                
             }
         }
       if ((counter < 3) && list[i] != 1) {//if the number is not one and has less than two factors then it is a prime number
          System.out.print(list[i] + " ");
       }
        
        counter =0;
    }
        }
}

