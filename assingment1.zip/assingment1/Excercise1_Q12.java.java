//The number of R's in a path is the position of the slot where the ball falls
import java.util.Scanner; 
public class Excercise1_Q12{
    public static void main(){
        Scanner myObj = new Scanner(System.in);
        System.out.println("Enter the number of balls to drop:");
        int balls = myObj.nextInt();
        System.out.println("Enter the number of slots in the bean machine:");
        int numslots = myObj.nextInt();
        //write a for loop that generates a random number one or two  for the number of slots
        int[] slots = new int[numslots];
        int counter =0;
        for (int w=0;w<balls;w++){//repeats for number of balls
        for (int i = 0;i<numslots ; i++){
            int rng = (int)(Math.random() *2);
            if (rng == 0){
                //Left =0
                System.out.print("L");
            }else if (rng==1){
                System.out.print("R");
                counter++;//counting the number of rights
            }
            
        }
        slots[counter]++;//adding a ball to the slot
        System.out.println();
        counter= 0;
    }
    int max = 0;
    int maxval=0;
    for (int h =0;h<slots.length; h++){//iterate through each entry in the array
        if (slots[h] > maxval){
        max= h;
        maxval= slots[h];//creating an initial max value in the array 
    }
    //System.out.print(slots[h]);
}
//System.out.println();
    //System.out.println("The most balls are in a slot is " + maxval);
  for(int u=balls;u>0;u--){//Loop runs for the number of balls dropped
    for (int y=0;y<slots.length;y++){
        if (slots[y] == maxval && maxval !=0){ //if there  is a ball at that level drop it into the appropriate slot
            System.out.print("0");
            slots[y]--;//ball droppes so we subtract one from that slot

        }else{
            System.out.print(" ");
        }
}
maxval--;//decreasing the max value by one ball
 System.out.println();
}
//find the array entry with the most balls
//Start by printing 0 in the array slot with the most entries
//
}
}