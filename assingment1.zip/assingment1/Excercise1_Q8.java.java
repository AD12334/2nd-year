import java.util.Scanner;
public class Excercise1_Q8{
   public static void Q8(){
             Scanner myObj = new Scanner(System.in);
    System.out.println("Input number");
    int input =myObj.nextInt();
System.out.print("The sum of the first n numbers is " );    
int i = 0;
int sum =0;
while (i < input+1){
    sum +=i;
    i++;
}
System.out.println( sum);
        }
}

