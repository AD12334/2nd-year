import java.util.Scanner;
public class Excercise1_Q4{
public static void Q4(){
    Scanner myObj = new Scanner(System.in);
    System.out.println("Enter employee name:");
    String Name = myObj.nextLine();
    System.out.println("Enter number of hours worked in a week:");
    int hours = myObj.nextInt();
    System.out.println("Enter hourly pay rate:");
    double pay = myObj.nextDouble();
    System.out.println("Enter federal tax withholding rate as a decimal:");//user enters number between 0 & 1
    double tax = myObj.nextDouble();
    while (tax>1){
        System.out.print("Error please enter your correct federal tax return rate as a decimal: ");
        tax = myObj.nextDouble();
    }
    System.out.println("Enter state tax withholding rate as a decimal:");//user enters number between 0 & 1
    double state = myObj.nextDouble();
    while (state>1){
        System.out.print("Error please enter your correct state tax withholding rate as a decimal: ");
        tax = myObj.nextDouble();
    }
    System.out.println("Employee Name: " + Name);
    System.out.println("Hours worked: " + hours);
    System.out.println("Pay rate: " + pay);
    System.out.println("Gross pay: " + pay*hours);
    System.out.println("Deductions:");
    System.out.println("Federal Withholding: " + tax*pay);
    System.out.println("State Withholding: " + state*pay);
    System.out.println("Total deductions: " + ((state*pay)+(tax*pay)));
    System.out.println("Net pay: " + ((pay*hours) -((state*pay)+(tax*pay))));
}
}
