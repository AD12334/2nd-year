import java.util.Arrays;

public class Excercise1_Q11{
    public static int getRandom (int... numbers){
        int rng = (int)(Math.random() * 54 +1);
        int length = numbers.length;
        //numbers.isPresent()
 //for each entry in the array
 //check if its equal to the rng
 //if the rng is equal to the number make a new rng 
 //return the rng
 
 int counter =0;
 for (int q = 0;q<numbers.length;q++){
     //make a counter variable that checks through how many equals are in the array
     //if the number of equals is greater than one then there is a match 
     //generate a new rng and try again
     //else return the number
     if (numbers[q] == rng){
        rng = (int)(Math.random() * 54 +1);
         
     } 
 }
 return rng;
 }
}

