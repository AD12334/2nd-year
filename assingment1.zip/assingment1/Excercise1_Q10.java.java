public class Excercise1_Q10{
    public static double footToMeter(double foot){
        double meter = 0.305 * foot;
        return meter;
    }
    public static double meterToFoot(double meter){
        double foot = meter * 3.279;
        return foot;
    }
}
