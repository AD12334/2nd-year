public class Excercise1_Q3{
     public static double Q3(double x){
        //Monthly interest rate is 0.00417
        //100 * (1+0.00417) = 100.417
        // (100+100.417) * ( 1+0.00417) = 201.252
        //six months
        double value = 0;
        int i = 0; // initially no months have passed
        while( i < 6){
            value= (x + value) * ( 1 + 0.00417);
            i++;
        
    }
    return value;
}
}
