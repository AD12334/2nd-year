public class Excercise1_Q2{
    public static void Q2(){
        double numerator = ((7.5*2.5) - (1.5*3));
        double denominator = (35.5- 2.5);
        double result = numerator/denominator;
        System.out.println(result);
        
        
    }
}
