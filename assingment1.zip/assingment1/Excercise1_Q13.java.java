public class Excercise1_Q13{
public static double sumColumn(double[][] m, int columnIndex){
    //get the sum of the entries of the columns
    //read the first row first column
    //add to first row +1 first column 
    //continue until we reach the last row
    //repeat for remaining columns
    double sum=0;
    for (int y =0; y<m.length;y++){
    sum+= m[y][columnIndex];
    }
return sum;
}
}
