public class rectangletester {
    public static void main(String[] args) {
        Rectangle rectangle1 = new Rectangle(1, 1);
        Rectangle rectangle2 = new Rectangle(4, 5.5);
        System.out.println("Rectangle 1 area = " + rectangle1.getArea());
        System.out.println("Rectangle 1 peremiter = " + rectangle1.getPerimeter());
        System.out.println("Rectangle 1 width = " +rectangle1.getWidth());
        System.out.println("Rectangle 1 height = " +rectangle1.getHeight());
        System.out.println( "Rectangle 2 area = " +rectangle2.getArea());
        System.out.println("Rectangle 2 perimeter = " +rectangle2.getPerimeter());
        System.out.println("Rectangle 2 width = " + rectangle2.getWidth());
        System.out.println("Rectangle 2 height = " +rectangle2.getHeight());


    }
}
