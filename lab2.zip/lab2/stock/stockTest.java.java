public  class stockTest {
    public static void main(String[] args){
    Stock stock = new Stock();
    stock.setSymbol("LKSS");
    stock.setName("Limerick Software solutions");
    stock.setCurrentPrice(79.65);
    stock.setPreviousClosingPrice(79.45);
    System.out.println("Stock symbol: " +stock.getSymbol());
    System.out.println("Stock name: " +stock.getName());
    System.out.println("Stock current price: " +stock.getCurrentPrice());
    System.out.println("Stock closing price: " +stock.getPreviousClosingPrice());
    System.out.println("Stock percentage change: " +stock.getChangePercent());
    }
}
