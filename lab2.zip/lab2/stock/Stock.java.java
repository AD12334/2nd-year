public class Stock{
private String symbol;
private String name;
private double previousClosingPrice;
private double currentPrice;
public Stock(){
    this.symbol = symbol;
    this.name = name;
}
public double getChangePercent(){
    return (previousClosingPrice - currentPrice)/previousClosingPrice;
}
public void setSymbol(String symbol){
        this.symbol = symbol;
    }
public String getSymbol(){
    return symbol;
}
public void setName(String name){
    this.name = name;
}
public String getName(){
    return name;
}
public void setPreviousClosingPrice(double previousClosingPrice){
    this.previousClosingPrice = previousClosingPrice;
}
public double getPreviousClosingPrice(){
    return previousClosingPrice;
}
public void setCurrentPrice(double currentPrice){
    this.currentPrice = currentPrice;
}
public double getCurrentPrice(){
    return currentPrice;
}

}